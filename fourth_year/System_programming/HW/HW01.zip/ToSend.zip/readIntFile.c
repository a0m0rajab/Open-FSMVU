#include <stdio.h>
#include <stdlib.h>

void _final(int n, int *arr);
int main(int argc, char *argv[])
{

    int count = 0;
    int i = 0;
    // int *array;
    FILE *fp;   
    printf("reading the file...");

    if (fp = fopen(argv[1], "r"))
    {
        fscanf(fp, "%d", &count);
        printf("reading the file...1 ");
        int array[count];
        // array= (int*)malloc(sizeof(int)*count);
        printf("reading the file...");
        if (array == NULL)
        {
            printf("error");
            exit(0);
        }

        while (fscanf(fp, "%d", &array[i]) != EOF)
        {
            ++i;
        }
        fclose(fp);
    }

    printf(" count %d\n", count);
    for (--i; i >= 0; --i)
        printf("%d \n ", array[i]);

    //_final(count,array);
    // printf("Sorted Array \n");

    for (i = count; i >= 0; --i)
        printf("%d , ", array[i]);

    return 0;
}
