Abdurrahman TAHA,
Abdurrahman RAJAB

Approach: 
we tried to write our own couint sort in assemlby with few (failed) attempts, you can see it at final1.asm,sort.asm, 
theoritically it should work, but we got segmentaion error, we modified the sent array and returned it instead of creating a new array+ used the local
variables in assembly to set the count array, instead of checking the range of count array we initialised it till the max number of the input array. 

the c files is normal c files, shall we explain it? 

the dissort.c, dissort.asm was our lifeboat to solve this problem and get the needed results and show it.


CountinsSortAlgo.c 
implementing the usage of counting sort by input from user 

readIntFile.c
read input file from user sort it then show the sorted array.

disSort.c 
Count sort algorithm written in C file

disSort.asm
Disassembling counting sort algorithm by using the intel assembly language, used objdump -m intel

nums.txt 
numbers file to read by c function, the first element is the count of numbers.

final1.asm
sort.asm 
two assembly files written by hand to implement counting sort in assembly.

