from sklearn.datasets import fetch_openml
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
import numpy as np

X, y = fetch_openml('mnist_784', version=1, return_X_y=True)
X = X / 255

X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, random_state=42)

parameters = {'solver': ['lbfgs'], 
'max_iter': [50,100], 
'alpha':10.0 ** -np.arange(3, 5), 
'hidden_layer_sizes':np.arange(1, 3),
'random_state':[1]}
grid = GridSearchCV(MLPClassifier(), parameters,n_jobs=-1)
grid.fit(X_train, y_train)
print('Best parameters:{}'.format(grid.best_params_))