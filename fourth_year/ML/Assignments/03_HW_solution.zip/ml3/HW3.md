#Machine learning HW3 

- [Data set: Mnist](#data-set-mnist)
- [Requirements](#requirements)
- [Code implementation](#code-implementation)
  - [Libraries used](#libraries-used)
  - [Loading the data](#loading-the-data)
  - [Splitting the data](#splitting-the-data)
  - [Default mode](#default-mode)
  - [Activation Function](#activation-function)
  - [Regulation value](#regulation-value)
  - [Hiddent units](#hiddent-units)
  - [2 hidden layers](#2-hidden-layers)
  - [3 hidden layers](#3-hidden-layers)
- [Activation function Results table](#activation-function-results-table)
  - [Comment](#comment)
- [Regular parameter Results table](#regular-parameter-results-table)
  - [Comment](#comment-1)
- [Hidden Units Results table](#hidden-units-results-table)
  - [Comment](#comment-2)
- [Hidden Layers Results table](#hidden-layers-results-table)
  - [Comment](#comment-3)
- [GridSearchCV](#gridsearchcv)
  - [comment](#comment-4)
- [Referencese](#referencese)
  - [The time for SearchGrid to let it work](#the-time-for-searchgrid-to-let-it-work)
  - [Reg parameter infroamtion](#reg-parameter-infroamtion)


## Data set: Mnist
The MNIST database of handwritten digits, available from this page, has a training set of 60,000 examples, and a test set of 10,000 examples. It is a subset of a larger set available from NIST. The digits have been size-normalized and centered in a fixed-size image.

## Requirements
Checking the effect of different
* choice of activation functions
* values of regularization parameters
* numbers of hidden units (single hidden layer)
* numbers of hidden layers 

Using GridSearchCV to optimize your neural network's hyper-parameters
automatically. 
## Code implementation 

### Libraries used
```python
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_openml
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
```



### Loading the data
```python
X, y = fetch_openml('mnist_784', version=1, return_X_y=True)
X = X / 255

```

### Splitting the data
```python
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, random_state=42)
```

### Default mode
```python
mlp = MLPClassifier()

nn1 = mlp.fit(X_train, y_train)
print("Training set score: %f" % mlp.score(X_train, y_train))
print("Test set score: %f" % mlp.score(X_test, y_test))
```

    Training set score: 1.000000
    Test set score: 0.976629


### Activation Function

```python
# activation{‘identity’, ‘logistic’, ‘tanh’, ‘relu’}, default=’relu’
print("Hello")
from mlxtend.plotting import plot_decision_regions
import matplotlib.pyplot as plt

ActivationFunction = ['identity', 'logistic', 'tanh', 'relu']
for word in ActivationFunction:
    print(word)
    mlp = MLPClassifier(activation=word)
    nn1 = mlp.fit(X_train, y_train)
    print("Training set score: %f" % mlp.score(X_train, y_train))
    print("Test set score: %f" % mlp.score(X_test, y_test))


```

    identity
    Training set score: 0.941848
    Test set score: 0.917086
    logistic
    Training set score: 1.000000
    Test set score: 0.975200
    tanh
    Training set score: 0.999086
    Test set score: 0.971886
    relu
    Training set score: 0.998971
    Test set score: 0.977429


### Regulation value

```python
regValue = [0.0001,0.0002,0.001,0.002,0.1,0.2,1,2]
for value in regValue:
    print(value)
    mlp = MLPClassifier(alpha=value)
    mlp.fit(X_train, y_train)
    print("Training set score: %f" % mlp.score(X_train, y_train))
    print("Test set score: %f" % mlp.score(X_test, y_test))
```

    0.0001
    Training set score: 1.000000
    Test set score: 0.977029
    0.0002
    Training set score: 1.000000
    Test set score: 0.978743
    0.001
    Training set score: 1.000000
    Test set score: 0.976114
    0.002
    Training set score: 1.000000
    Test set score: 0.978629
    0.1
    Training set score: 0.994648
    Test set score: 0.979257
    0.2
    Training set score: 0.986743
    Test set score: 0.975257
    1
    Training set score: 0.959562
    Test set score: 0.952000
    2
    Training set score: 0.939810
    Test set score: 0.933200

### Hiddent units

```python
hiddenUnits = [1,2,5,10,20,30,100]
for value in hiddenUnits:
    print(value)
    mlp = MLPClassifier(hidden_layer_sizes=[value])
    mlp.fit(X_train, y_train)
    print("Training set score: %f" % mlp.score(X_train, y_train))
    print("Test set score: %f" % mlp.score(X_test, y_test))
```
    1
    Training set score: 0.398724
    Test set score: 0.397771
    2
    Training set score: 0.702971
    Test set score: 0.702114
    5
    Training set score: 0.909390
    Test set score: 0.893600
    10
    Training set score: 0.961848
    Test set score: 0.932629
    20
    Training set score: 0.996438
    Test set score: 0.948343
    30
    Training set score: 1.000000
    Test set score: 0.961543
    100
    Training set score: 1.000000
    Test set score: 0.977657

### 2 hidden layers

```python
print( '2 hidden layers with 100')
mlp = MLPClassifier(hidden_layer_sizes=[100,100])
mlp.fit(X_train, y_train)
print("Training set score: %f" % mlp.score(X_train, y_train))
print("Test set score: %f" % mlp.score(X_test, y_test))
```

    2 hidden layers with 100
    Training set score: 1.000000
    Test set score: 0.978800

### 3 hidden layers

```python
print( '3 hidden layers with 100')
mlp = MLPClassifier(hidden_layer_sizes=[100,100,100])
mlp.fit(X_train, y_train)
print("Training set score: %f" % mlp.score(X_train, y_train))
print("Test set score: %f" % mlp.score(X_test, y_test))
```

    3 hidden layers with 100
    Training set score: 0.998838
    Test set score: 0.976914

## Activation function Results table
|  Value   | identity | logistic |   tanh   |   relu   |
| :------: | :------: | :------: | :------: | :------: |
| training | 0.941848 | 1.000000 | 0.999086 | 0.998971 |
|   test   | 0.917086 | 0.975200 | 0.971886 | 0.977429 |

### Comment
As we see from the aboe results, chaning the Activation function canm make a difference in the results we can see that Relu function ourperfromed the others  for it. 

## Regular parameter Results table

| Value  | set Score | Test Score |
| :----: | :-------: | :--------: |
| 0.0001 | 1.000000  |  0.977029  |
| 0.0002 | 1.000000  |  0.978743  |
| 0.001  | 1.000000  |  0.976114  |
| 0.002  | 1.000000  |  0.978629  |
|  0.1   | 0.994648  |  0.979257  |
|  0.2   | 0.986743  |  0.975257  |
|   1    | 0.959562  |  0.952000  |
|   2    | 0.939810  |  0.933200  |

### Comment
as we can see the best score for this was the 0.002 and 0.002 with slightly changes the larger we have it we see the larger difference in the results since its used to reduce the overfitting 

## Hidden Units Results table

| Value | set Score | Test Score |
| :---: | :-------: | :--------: |
|   1   | 0.398724  |  0.397771  |
|   2   | 0.702971  |  0.702114  |
|   5   | 0.909390  |  0.893600  |
|  10   | 0.961848  |  0.932629  |
|  20   | 0.996438  |  0.948343  |
|  30   | 1.000000  |  0.961543  |
|  100  | 1.000000  |  0.977657  |

### Comment
Here we can see the hidden units, the more it added the better results we have, like we can see the change from 1 to 2 added a 100% better performance to our model.

## Hidden Layers Results table

2 hidden layers with 100
    Training set score: 1.000000
    Test set score: 0.978800
    3 hidden layers with 100
    Training set score: 0.998838
    Test set score: 0.976914

### Comment
Here we can see a slightly change with the hidden layers and adding one more layer to our function had it go down and not get overfit since it will be able to get the results and learn the edge situations from model, which make it differ.

## GridSearchCV

```python
grid = GridSearchCV(MLPClassifier(), parameters,n_jobs=-1)
grid.fit(X_train, y_train)
print('Best parameters:{}'.format(grid.best_params_))
```
Try 1
```python
parameters = {'solver': ['lbfgs'], 
            'max_iter': [500],
            'activation': ['identity', 'logistic', 'tanh', 'relu'],
            'alpha':[0 , 0.1, 1.0],
            'hidden_layer_sizes':[[1],[1,1],[1,1,1]],
              }
```
              
try 2
```python
parameters = {'solver': ['lbfgs'], 
            'max_iter': [500,1000,1500],
            'activation': ['identity', 'logistic', 'tanh', 'relu'],
            'alpha':[0 , 0.5 , 0.1, 1.0],
            'hidden_layer_sizes':[[1],[20] ,[100],
                                    [1,1],[20,20],
                                    [1,1,1],[10,10,10]],
            'random_state':[0,1,2,3,4,5,6,7,8,9]
              }
```
Try 3
```python
parameters = {'solver': ['lbfgs'], 
            'max_iter': [500,1000,1500],
            'activation': ['identity', 'logistic', 'tanh', 'relu'],
            'alpha':[0 , 0.5 , 0.1, 1.0],
            'hidden_layer_sizes':[[1],[20] ,[100],
                                    [1,1],[20,20],
                                    [1,1,1],[10,10,10]],
            'random_state':[0,1,2,3,4,5,6,7,8,9]
              }
```

### comment
The gridSearchVc function try to get the best parameters from our algorthm yet i could not run it since it took a lot of time and could not got any results out of it, For try 1 and 2 ,it get the pc crashed few times, it took more than 10 hours to get a result yet it did not work, the less parameters we have the less time it take which i decided to have on my try 3  and got a result as 

```python
Best parameters:{'alpha': 0.001, 'hidden_layer_sizes': 2, 'max_iter': 100, 'random_state': 1, 'solver': 'lbfgs'}
````
then tried to add the activation function and had this result: 

```python
Best parameters:{'activation': 'identity', 'alpha': 0.1, 'hidden_layer_sizes': [1], 'max_iter': 500, 'solver': 'lbfgs'}
```

## Referencese

###Basic information
Machine leraning Andrew NG coursera 
Machine learningcodes from the lecture 
Sickit library codes
http://yann.lecun.com/exdb/mnist/
https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.MLPClassifier.html

### The time for SearchGrid to let it work 
https://datascience.stackexchange.com/questions/29495/how-to-estimate-gridsearchcv-computing-time
### Reg parameter infroamtion
https://stackoverflow.com/questions/12182063/how-to-calculate-the-regularization-parameter-in-linear-regression

