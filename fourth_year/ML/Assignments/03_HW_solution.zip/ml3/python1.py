from sklearn.datasets import fetch_openml
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV


X, y = fetch_openml('mnist_784', version=1, return_X_y=True)
X = X / 255

X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, random_state=42)

parameters = {'solver': ['lbfgs'], 
            'max_iter': [500,1000,1500],
            'activation': ['identity', 'logistic', 'tanh', 'relu'],
            'alpha':[0 , 0.5 , 0.1, 1.0],
            'hidden_layer_sizes':[[1],[20] ,[100],
                                    [1,1],[20,20],
                                    [1,1,1],[10,10,10]],
            'random_state':[0,1,2,3,4,5,6,7,8,9]
              }
grid = GridSearchCV(MLPClassifier(), parameters,n_jobs=-1)
grid.fit(X_train, y_train)
print('Best parameters:{}'.format(grid.best_params_))