For the homework, 
I have assumed that the given input is the final one,
to use it in different input we need to change the array information, 
length, inputs, count length and output 

Beside that i could not use the READWRITE space even 
when i changed the options in keil, which would make the code much cleaner and easier 

That's why i used the addresses immediatly.