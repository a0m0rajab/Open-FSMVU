# Homework 1

## Question 1: 

$ \frac{\partial (MSE(\theta_j))}{\partial \theta_j} =   \frac{1}{m} \sum\limits_{i=0}^m 2({\theta^T \cdot x^i - y^i}) \cdot x^i$

$ x^i = 1 $

$ \frac{\partial (MSE(\theta_j))}{\partial \theta_j} =   \frac{1}{m} \sum\limits_{i=0}^m 2({\theta^T \cdot x^i - y^i}) $

## Question 2: 

$ \frac{\partial (MSE(\theta_0))}{\partial \theta_0} =   \frac{1}{m} \sum\limits_{i=0}^m 2({\theta^T \cdot x^i - y^i}) \cdot x^i$

$ \frac{\partial (MSE(\theta_1))}{\partial \theta_1} =   \frac{1}{m} \sum\limits_{i=0}^m 2({\theta^T \cdot x^i - y^i}) \cdot x^i$

$ \frac{\partial (MSE(\theta_n))}{\partial \theta_n} =   \frac{1}{m} \sum\limits_{i=0}^m 2({\theta^T \cdot x^i - y^i}) \cdot x^i$


$ \frac{\partial (MSE(\theta_n))}{\partial \theta_n} =   \frac{2}{m}  X^T({\theta^T \cdot X - y})$

.
.
$ \nabla_\theta MSE(\theta)
\begin{bmatrix}
\frac{\partial }{\partial \theta_0} MSE(\theta_0) \\ \\
\frac{\partial }{\partial \theta_0}  MSE(\theta_0) \\  \\
\vdots \\ 
\frac{\partial }{\partial \theta_0}  MSE(\theta_0)
\end{bmatrix} =   \frac{2}{m}  X^T({\theta^T \cdot X - y})
$

## Implementation part and report: 
The code is sent as well beside this file. 
 
I used the train_test_split function to split the data on train and test parts, then used the linearRegression model to train the data and get the prediction 

```python
from sklearn.linear_model import LinearRegression
lrm = LinearRegression()
lrm.fit(X_train, Y_train)
Y_pred = lrm.predict(X_test)
```
The results of predicted and reality
![Predicted and reality](./predicted&#32;vs&#32;reality.png)

After that i had to use check the results of the    LinearRegression and calculated the initial MSE:

```python
df = pd.DataFrame({'Actual': Y_test, 'Predicted': Y_pred})
print(df)
print('Mean Squared Error:', sklearn.metrics.mean_squared_error(Y_test, Y_pred)) 
```
The results and the MSE
| Tables | Actual | Predicted |
| ------ | :----: | --------: |
| 0      |  37.6  | 37.467236 |
| 1      |  27.9  | 31.391547 |
| 2      |  22.6  | 27.120196 |
| 3      |  13.8  |  6.468433 |
| 4      |  35.2  | 33.629667 |
| ..     |  ...   |       ... |
| 162    |  14.4  |  9.718369 |
| 163    |  35.4  | 34.705200 |
| 164    |  25.3  | 25.704102 |
| 165    |  18.3  | 20.154309 |
| 166    |  16.6  | 15.394658 |
Mean Squared Error: 28.530458765974686

Then i have written the Gradient Descent MSE algorithm like : 
```Python 
def GDMSE(test,pred,learningRate,iteration=100,theta=100):
    history1 = [x for x in range(iteration)]
    history1[0]=theta;
    for i in range(100):
        theta = theta - learningRate * sklearn.metrics.mean_squared_error(test, pred)
        history1[i]=theta;
        print(i,theta)
    plt.figure(figsize=(20,10))
    plt.scatter(history1, [x for x in range(iteration)])
``` 
it takes the number of iteration and Theta as parameters and set as default for 100, and takes the predicted and the test data to calculated the results with the learning rate. 

You can find the result of 0.1,0.5,0.002 Learning rates in the python code. 

Since it's the same and only needed to change the learning rates value.
```python
GDMSE(Y_test,Y_pred,0.02)
``` 
### Results
For the learning rates and the iterations we have three possiblities which is: 
Slow learning Rate:
Optimal Learning Rate: 
High Learning Rate:

#### References: 
andrew ng machine learning stanford
ethem alpaydın machine learning 
https://scikit-learn.org/ docs
https://developers.google.com/machine-learning/crash-course/fitter/graph