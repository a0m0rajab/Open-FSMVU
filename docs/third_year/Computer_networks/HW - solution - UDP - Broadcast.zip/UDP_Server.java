package UDP_SwingUI;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * @file UDP_Server.java
 * @date Feb 24, 2020 , 13:24:00
 * @author Muhammet Alkan
 */
public class UDP_Server {

    private DatagramSocket serverSocket;
    private Thread serverThread;
    private javax.swing.JTextPane historyJTextPane;
    private ArrayList<serverInformation> clientList=new ArrayList<serverInformation>();    

    protected void start(int port, javax.swing.JTextPane jTextPaneHistory) throws Exception {
        // server arayüzündeki history alanı, bütün olaylar buraya yazılacak
        this.historyJTextPane = jTextPaneHistory;

        // server soketi (DatagramSocket) oluşturma (sadece port numarası)
        serverSocket = new DatagramSocket(port);
        serverSocket.setBroadcast(true);

        System.out.println("Server başlatıldı ..");

        // DatagramPacket, gelen mesaj bu paket içerisine alınacak
        byte[] data = new byte[1024];
        DatagramPacket packet = new DatagramPacket(data, data.length);

        serverThread = new Thread(() -> {
            while (true) {
                try {
                    // blocking call, yeni bir DatagramPacket gelmesini bekler
                    // gelen paketi yukarıda oluşturulan DatagramPacket'e yazar
                    serverSocket.receive(packet);

                    // gönderilen String mesajını al (mesaj uzunluğu kadarını alır)
                    // paket içerisindeki data boyutu daha fazla olabilir, sadece gereken kısmı alıyoruz
                    String receivedMessage = new String(packet.getData(), 0, packet.getLength());
                    if(receivedMessage.contains("Yeni kullanici katildi ")){  
                      this.sendBroadcast("Yeni kullanici katildi.");
                       clientList.add(new serverInformation(packet.getAddress(),packet.getPort()));
                    }else if(receivedMessage.equals("son")){
                       this.sendBroadcast("bir kullanici cikti");
                       clientList.remove(new serverInformation(packet.getAddress(),packet.getPort()));
                    }else {
                        this.sendBroadcast(packet.getSocketAddress() +" says " + receivedMessage);

                    }
                    writeToHistory(packet.getSocketAddress() + " received : " + receivedMessage);
                } catch (Exception ex) {
                    System.out.println("Hata - new Thread() : " + ex);
                    break;
                }
            }
        });
        serverThread.start();
    }

    protected void writeToHistory(String message) {
        // server arayüzündeki history alanına mesajı yaz
        historyJTextPane.setText(historyJTextPane.getText() + "\n" + message);
    }

    protected void stop() {
        if (serverSocket != null) {
            serverSocket.close();
        }
    }
    
    // TODO: send broadcast message to all clients
    protected void sendBroadcast(String message) throws Exception {
        byte[] buf = message.getBytes();
        clientList.forEach(e -> {
            try {
                serverSocket.send(new DatagramPacket(buf, buf.length, e.addres, e.port));
            } catch (IOException ex) {
                Logger.getLogger(UDP_Server.class.getName()).log(Level.SEVERE, null, ex);
            }

        } );
    }
   

}
